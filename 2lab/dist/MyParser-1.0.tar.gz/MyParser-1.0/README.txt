Description
===========

Self-made json, yaml, toml, pickle serializer.